function unset()
%
% Unset environment variable OSLCONF.
%
% See also: osl_conf.set
%
% JH

    setenv('OSLCONF');
    
end