function set(cpath)
%
% Set environment variable OSLCONF.
%
% See also: osl_conf.unset
%
% JH

    setenv('OSLCONF',cpath);
    
end