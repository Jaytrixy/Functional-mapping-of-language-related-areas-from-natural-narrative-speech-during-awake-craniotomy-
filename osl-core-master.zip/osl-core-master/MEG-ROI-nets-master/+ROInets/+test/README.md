### Unit Tests

To run all tests, use

	ROInets.test.run

Each file in this directory, with the exception of `run.m`, tests a different feature provided by this package