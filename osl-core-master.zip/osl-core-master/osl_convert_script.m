function osl_convert_script(varargin)
    error('This function is now called ''osl_import''')