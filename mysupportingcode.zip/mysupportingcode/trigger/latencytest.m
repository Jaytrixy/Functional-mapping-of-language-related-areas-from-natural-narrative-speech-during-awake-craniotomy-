clear;
T = zeros(1,100);
S = zeros(1,100);
t0 =tic;
s0 = GetSecs;
alltrial = (1:300);
for itrial=1:length(alltrial)
    trial=alltrial(itrial);
    outp(888,trial);T(itrial) = toc(t0); S(itrial) = GetSecs;pause(0.001);outp(888,0);disp(itrial);
    pause(1);
end