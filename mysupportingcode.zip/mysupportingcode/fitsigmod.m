function fitsigmod(x,y)

% convert to column vectors
if size(x,1)==1
    x = x';
    y = y';
end

% 1st fit, using fittpye
expression =[num2str(max(y)), '/(1+exp(-b*(x+a)))'];
tryfit = fittype(expression,'dependent',{'y'},'independent',{'x'},'coefficient',{'a','b'});
options = fitoptions(tryfit);
options.StartPoint = [-x(1) 0];
options.maxfunevals = 10000;
options.maxiter = 10000;
options.Lower = [-inf, -inf];
options.Upper = [inf, inf];
options.algorithm = 'trust-region';
[coef] = fit([x],[y],tryfit,options);
a1 = coef.a;
b1 = coef.b;
Y1 = max(y)*1.001./(1+exp(-b1*(x+a1)));

% 2nd fit, using linear regression
x2=x;
y2=log(max(y)*1.001./y-1);
mdl = fitlm(x2,y2);
a2 = mdl.Coefficients{1,1}/mdl.Coefficients{2,1};
b2 = -mdl.Coefficients{2,1};
Y2 = max(y)*1.01./(1+exp(-b2*(x+a2)));
% plot
hold on;
t = linspace(-max(x),max(x),500);
Yt1 = max(y)*1.001./(1+exp(-b1*(t+a1)));
Yt2 = max(y)*1.001./(1+exp(-b2*(t+a2)));
plot(x,y);
plot(t,Yt1);
plot(t,Yt2);
legend({'Original',[num2str(max(y)), '/(1+exp(-',num2str(b1),'*(x+',num2str(a1),')))']...
    ,[num2str(max(y)),'/(1+exp(-',num2str(b2),'*(x+',num2str(a2),')))']}...
    ,'location','best','Interpreter','latex');