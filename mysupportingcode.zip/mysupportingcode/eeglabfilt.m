function out=eeglabfilt(signal,hb,lb,notch)
if nargin < 4
    notch = 0;
end
%% Data filtering
EEG.data = signal;
EEG.srate=2500;
EEG.trials=1;
EEG.event=[];
EEG.pnts=length(EEG.data);
EEG = pop_eegfiltnew(EEG, hb,lb, [],notch,[], 0, []);
out = EEG.data;