
function [W,COI] = MWT(data,dt,a,w0);

%    Morlet Contionous wavelet transfrom with Cone-of-Influence (edge effect!)
%
%   [W,COI] = MWT(data,dt,a,w0)
%
%   Computes Morlet wavelet transform of a time series: data 
%   
%%   By default, the Morlet wavelet (k0=6) is used.
%   The wavelet basis is normalized to have total energy=1 at all scales.
%
%
% INPUTS:
%
%    data = the time series of length N.
%    dt = the sampling time.
%    a = the scales.
%    w0 = central frequency ( > or = 6)
%
% OUTPUTS:
%
%    W is the Morlet transfrom of X. 
%    COI = the Cone-of-Influence. 

%    Xiaoli Li, March 18, 2005


if (nargin < 4), w0=6; end

if (nargin < 3)
	error('Must input a vector X, sampling time dt, and scales a')
end

Len = length(data);

% Prepare of data for FFT! The data should be the power of 2 (64, 128, ...). 
% if no, pad data with enough zeros to get N up to the next highr power of 2.  
% The advantge of the extension of data (a) prevents wraparound from the
% end of the time series to the begining; (b) speed up the FFT!

% x(1:Len) = data - mean(data);
x(1:Len) = (data - mean(data))/std(data) ;

base2 = fix(log(Len)/log(2) + 0.4999);   % power of 2 nearest to N
x = [x,zeros(1,2^(base2+1)-Len)];

n = length(x);

% FFT of the (padded) time series x

f = fft(x);    

% Angular frequency [Eqn(5)]

k = [1:fix(n/2)]; 
k = k.*((2.*pi)/(n*dt)); 
k = [0., k, -k(fix((n-1)/2):-1:1)];    %  Equation (7) 

% Construct W arrays 
J=length(a);     % length of scale vector a     
W = zeros(J,n);  % define the wavelet array
W = W + i*W;     % make it complex

% Loop for all of scales and IFFT transform

for ii=1:J
    [mw,~]=MWT_base(k,a(ii),w0);	
     W(ii,:) = ifft(f.*mw);% Equation (8)
 end
[~,coi]=MWT_base(k,a(J),w0);
COI = coi*dt*[1E-5,1:((Len+1)/2-1),fliplr((1:(Len/2-1))),1E-5];          % COI this is fourier period, 
%COI = 1./coi;

W = W(:,1:Len);  % get rid of padding before returning

return,

% -------------------------------------------------------------------------
% -----------------------------------------------------------------------

function [mw,coi]=MWT_base(k,scale,w0)

% k is the angular frequency
% s is a(i) scale
% cnteral frequency of wavelet transform 

n = length(k);

expnt = -(scale.*k - w0).^2/2.*(k > 0.);
norm = sqrt(scale*k(2))*(pi^(-0.25))*sqrt(n);       % total energy=N   
mw = norm*exp(expnt);
mw = mw.*(k > 0.);                                   % Heaviside step function

fourier_factor = (4*pi)/(w0 + sqrt(2 + w0^2));    %   Scale--> period factor
coi = fourier_factor/sqrt(2);                        % Cone-of-influence 

return,



