% %% new_epoch Segmentation
% % markers = N/2 trials * 2 colum 
listen = find(markers(:,1)<=30);
hear = find(markers(:,1)>30&markers(:,1)<=60);

read = find(markers(:,1)>=100&markers(:,1)<=130);
see = find(markers(:,1)>130&markers(:,1)<=160);

speak = find (markers(:,1)==241|markers(:,1)==242);
sentence = find(markers(:,1)==243);

%% for segmentation0
stim_T1 = markers(listen,2);
Tl_ans = 7500;  % -1000 ms to 2000 ms  of articulation
Tn = size(stim_T1,1);
data0 = zeros(64,Tl_ans,Tn);
for trail = 1 : Tn
    trigger = stim_T1(trail);
    data0(:,:,trail) = ALLEEG.data(:,trigger-2500:trigger+4999);
end
save listen_data data0

stim_T1 = markers(hear,2);
Tl_ans = 7500;  % -1000 ms to 2000 ms  of articulation
Tn = size(stim_T1,1);
data00 = zeros(64,Tl_ans,Tn);
for trail = 1 : Tn
    trigger = stim_T1(trail);
    data00(:,:,trail) = ALLEEG.data(:,trigger-2500:trigger+4999);
end
save hear_data data00


%% for segmentation1
stim_T1 = markers(read,2);
Tl_ans = 7500;  % -1000 ms to 2000 ms  of articulation
Tn = size(stim_T1,1);
data1 = zeros(64,Tl_ans,Tn);
for trail = 1 : Tn
    trigger = stim_T1(trail);
    data1(:,:,trail) = ALLEEG.data(:,trigger-2500:trigger+4999);
end
save read_data data1

stim_T1 = markers(see,2);
Tl_ans = 7500;  % -1000 ms to 2000 ms  of articulation
Tn = size(stim_T1,1);
data10 = zeros(64,Tl_ans,Tn);
for trail = 1 : Tn
    trigger = stim_T1(trail);
    data10(:,:,trail) = ALLEEG.data(:,trigger-2500:trigger+4999);
end
save hear_data data10

%% for segmentation2
stim_T1 = markers(speak,2);
Tl_ans = 7500;  % -1000 ms to 2000 ms  of articulation
Tn = size(stim_T1,1);
data2 = zeros(64,Tl_ans,Tn);
for trail = 1 : Tn
    trigger = stim_T1(trail);
    data2(:,:,trail) = ALLEEG.data(:,trigger-2500:trigger+4999);
end
save speak_data data2

stim_T1 = markers(sentence,2);
Tl_ans = 7500;  % -1000 ms to 2000 ms  of articulation
Tn = size(stim_T1,1);
data22 = zeros(64,Tl_ans,Tn);
for trail = 1 : Tn
    trigger = stim_T1(trail);
    data22(:,:,trail) = ALLEEG.data(:,trigger-2500:trigger+4999);
end
save sentence_data data22

save markers markers

clearvars -except ALLEEG data0 data1 data2 data00 data10 data22 markers
%% time_frequency analysis
sr=2500;
fre=2:2:250;
xx=zeros(1,length(fre));
yy=fre;

for Ch=1:64
    
 f1=figure('position',[10 10 1800 900],'visible','on');

 %% data 0
baseline = 500:2000;
Trails_N=size(data0,3);
Data_L=size(data0,2);
    %continues wavelet transform
    cwt_data=single(zeros(length(fre),Data_L,Trails_N));
    k=makeGkernal(100,20);
    for tn=1:Trails_N
        cwt_data(:,:,tn)=single((abs(M_wt(data0(Ch,:,tn),1/sr,fre,7))).^2);
        cwt_data(:,:,tn)=filter2(k,cwt_data(:,:,tn));
    end
    % Baseline correct
    TF_ref=cwt_data(:,baseline,:);
    p_ref=mean(TF_ref,2);
    rep_p=repmat(p_ref,[1,Data_L,1]);
    ERS=cwt_data./rep_p-1;
    TF_mean = mean(ERS,3);
    % statictical inference
    [~,p]=ttest(cwt_data,rep_p,.05,'both',3);
    H=secondtest(p,20,10);
    subplot(2,3,1);
    imagesc(-1000:.4:2499.6,fre,TF_mean.*H,[-1 1]); axis xy;
    ylabel('Frequency (HZ)'), xlabel ('time (ms)'), title('Listen to Chinese');
    hold on;
    p=plot(xx,yy);
    set(p,'Color','red','LineWidth',2);
    hold off;
  %% data 00  
    baseline = 500:2000;
Trails_N=size(data00,3);
Data_L=size(data00,2);
    %continues wavelet transform
    cwt_data=single(zeros(length(fre),Data_L,Trails_N));
    k=makeGkernal(100,20);
    for tn=1:Trails_N
        cwt_data(:,:,tn)=single((abs(M_wt(data00(Ch,:,tn),1/sr,fre,7))).^2);
        cwt_data(:,:,tn)=filter2(k,cwt_data(:,:,tn));
    end
    % Baseline correct
    TF_ref=cwt_data(:,baseline,:);
    p_ref=mean(TF_ref,2);
    rep_p=repmat(p_ref,[1,Data_L,1]);
    ERS=cwt_data./rep_p-1;
    TF_mean = mean(ERS,3);
    % statictical inference
    [~,p]=ttest(cwt_data,rep_p,.05,'both',3);
    H=secondtest(p,20,10);
    subplot(2,3,4);
    imagesc(-1000:.4:2499.6,fre,TF_mean.*H,[-1 1]); axis xy;
    ylabel('Frequency (HZ)'), xlabel ('time (ms)'), title('Listen to Korean');
    hold on;
    p=plot(xx,yy);
    set(p,'Color','red','LineWidth',2);
    hold off;
%% data 1    
baseline = 500:2000;
Trails_N=size(data1,3);
Data_L=size(data1,2);
    %continues wavelet transform
    cwt_data=single(zeros(length(fre),Data_L,Trails_N));
    k=makeGkernal(100,20);
    for tn=1:Trails_N
        cwt_data(:,:,tn)=single((abs(M_wt(data1(Ch,:,tn),1/sr,fre,7))).^2);
        cwt_data(:,:,tn)=filter2(k,cwt_data(:,:,tn));
    end
    % Baseline correct
    TF_ref=cwt_data(:,baseline,:);
    p_ref=mean(TF_ref,2);
    rep_p=repmat(p_ref,[1,Data_L,1]);
    ERS=cwt_data./rep_p-1;
    TF_mean = mean(ERS,3);
    % statictical inference
    [~,p]=ttest(cwt_data,rep_p,.05,'both',3);
    H=secondtest(p,20,10);
    subplot(2,3,2);
    imagesc(-1000:.4:2499.6,fre,TF_mean.*H,[-1 1]); axis xy;
    ylabel('Frequency (HZ)'), xlabel ('time (ms)'), title('Read Chinese');
    hold on;
    p=plot(xx,yy);
    set(p,'Color','red','LineWidth',2);
    hold off;
    
    %% data 10    
baseline = 500:2000;
Trails_N=size(data10,3);
Data_L=size(data10,2);
    %continues wavelet transform
    cwt_data=single(zeros(length(fre),Data_L,Trails_N));
    k=makeGkernal(100,20);
    for tn=1:Trails_N
        cwt_data(:,:,tn)=single((abs(M_wt(data10(Ch,:,tn),1/sr,fre,7))).^2);
        cwt_data(:,:,tn)=filter2(k,cwt_data(:,:,tn));
    end
    % Baseline correct
    TF_ref=cwt_data(:,baseline,:);
    p_ref=mean(TF_ref,2);
    rep_p=repmat(p_ref,[1,Data_L,1]);
    ERS=cwt_data./rep_p-1;
    TF_mean = mean(ERS,3);
    % statictical inference
    [~,p]=ttest(cwt_data,rep_p,.05,'both',3);
    H=secondtest(p,20,10);
    subplot(2,3,5);
    imagesc(-1000:.4:2499.6,fre,TF_mean.*H,[-1 1]); axis xy;
    ylabel('Frequency (HZ)'), xlabel ('time (ms)'), title('Read Korean');
    hold on;
    p=plot(xx,yy);
    set(p,'Color','red','LineWidth',2);
    hold off;
    
 %% data2   
baseline = 6700:7200;
Trails_N=size(data2,3);
Data_L=size(data2,2);
    %continues wavelet transform
    cwt_data=single(zeros(length(fre),Data_L,Trails_N));
    k=makeGkernal(100,20);
    for tn=1:Trails_N
        cwt_data(:,:,tn)=single((abs(M_wt(data2(Ch,:,tn),1/sr,fre,7))).^2);
        cwt_data(:,:,tn)=filter2(k,cwt_data(:,:,tn));
    end
    % Baseline correct
    TF_ref=cwt_data(:,baseline,:);
    p_ref=mean(TF_ref,2);
    rep_p=repmat(p_ref,[1,Data_L,1]);
    ERS=cwt_data./rep_p-1;
    TF_mean = mean(ERS,3);
    % statictical inference
    [~,p]=ttest(cwt_data,rep_p,.05,'both',3);
    H=secondtest(p,20,10);
    subplot(2,3,3);
    imagesc(-1000:.4:2499.6,fre,TF_mean.*H,[-1 1]); axis xy;colorbar;
    ylabel('Frequency (HZ)'), xlabel ('time (ms)'), title('Speak word');
    hold on;
    p=plot(xx,yy);
    set(p,'Color','red','LineWidth',2);
    hold off;
%     %% data22
%     baseline = 300:7200;
% Trails_N=size(data22,3);
% Data_L=size(data22,2);
%     %continues wavelet transform
%     cwt_data=single(zeros(length(fre),Data_L,Trails_N));
%     k=makeGkernal(100,20);
%     for tn=1:Trails_N
%         cwt_data(:,:,tn)=single((abs(M_wt(data22(Ch,:,tn),1/sr,fre,7))).^2);
%         cwt_data(:,:,tn)=filter2(k,cwt_data(:,:,tn));
%     end
%     % Baseline correct
%     TF_ref=cwt_data(:,baseline,:);
%     p_ref=mean(TF_ref,2);
%     rep_p=repmat(p_ref,[1,Data_L,1]);
%     ERS=cwt_data./rep_p-1;
%     TF_mean = mean(ERS,3);
%     % statictical inference
%     [~,p]=ttest(cwt_data,rep_p,.05,'both',3);
%     H=secondtest(p,20,10);
%     subplot(2,3,6);
%     imagesc(-1000:.4:2499.6,fre,TF_mean.*H,[-1 1]); axis xy;colorbar;
%     ylabel('Frequency (HZ)'), xlabel ('time (ms)'), title('Speak sentence');
%     hold on;
%     p=plot(xx,yy);
%     set(p,'Color','red','LineWidth',2);
%     hold off;
    %% save plot
    set(f1, 'PaperPositionMode','auto');
    print(f1,'-dpng','-r0',['C',num2str(Ch),'.png']);
    close all;
    fprintf('ch%d  plotted\n',Ch)
end