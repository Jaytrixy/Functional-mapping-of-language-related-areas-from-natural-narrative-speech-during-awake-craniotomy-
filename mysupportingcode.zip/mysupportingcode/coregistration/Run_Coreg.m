%% input MR dicom and CT dicom to get a corregistered figure.
% Need spm12 toolbox and dicm2nii toolbox;
% Jianbin Wen
% Wcastle90@gmail.com
% Jun 14th, 2015
%% dicm2nii
% source
mridir=uigetdir('E:\','Please spercific a folder which contain T1 dicoms');
ctdir=uigetdir('E:\','Please spercific a folder which contain CT dicoms');
%folder to save result files.
redir = uigetdir('E:\','Choose folder to save results');
Sub_info = inputdlg('name (or ID, etc) =','Please enter the subject name or ID, etc',[1 80]);
subredir=[redir,'/',Sub_info{1}];
if exist(subredir,'dir')==0
    mkdir(redir,Sub_info{1});
end
% convert CT
redir_ct = [subredir,'/CT_nii'];
if exist(redir_ct,'dir')==0
    mkdir(subredir,'CT_nii');
end
dicm2nii(ctdir,redir_ct,0);
Files = dir(fullfile(redir_ct,'*.nii'));
fname=[redir_ct,'/',Files(1).name];
hdr=spm_vol(fname); 
vol=spm_read_vols(hdr);
hdr.mat(1,4)=-hdr.mat(1,1)*hdr.dim(1)/2;
hdr.mat(2,4)=-hdr.mat(2,2)*hdr.dim(2)/2;
hdr.mat(3,4)=-hdr.mat(3,3)*hdr.dim(3)/2;
hdr.fname=[redir_ct,'/CT.nii'];
cthdr=hdr;
cd(redir_ct);
spm_write_vol(hdr,vol);

% convert MRI
redir_mr = [subredir,'/MR_nii'];
if exist(redir_mr,'dir')==0
    mkdir(subredir,'MR_nii');
end
dicm2nii(mridir,redir_mr,0);
Files = dir(fullfile(redir_mr,'*.nii'));
fname=[redir_mr,'/',Files(1).name];
hdr=spm_vol(fname); 
vol=spm_read_vols(hdr);
hdr.fname=[redir_mr,'/MR.nii'];
cd (redir_mr);
spm_write_vol(hdr,vol);
mrhdr=hdr;

%% spm segmentation
h=msgbox('This step may take up to 10 minutes, DO JUST WAIT.','Segmentation','warn');
kouSPMdir = spm('Dir');
spm_jobman('initcfg')
nrun = 1; % enter the number of runs here
inputs = cell(0, nrun);
SPMdir = spm('Dir');
for crun = 1:nrun
end
spm('defaults', 'fMRI');
eval('spmscript_seg');
spm_jobman('run', matlabbatch, inputs{:});
clear matlabbatch;
if exist('h')==1 
    delete(h); 
end
%% spm coregistration and reslice
transP = spm_coreg(mrhdr,cthdr);
transM = spm_matrix(transP(:)');
nrun = 1; % enter the number of runs here
run 'spmcoreg_job.m';
inputs = cell(0, nrun);
for crun = 1:nrun
end
spm('defaults', 'FMRI');
spm_jobman('run', matlabbatch, inputs{:});

%% remove skull in CT images using coordinates from MR segments
c1hdr = spm_vol([redir_mr,'/c1MR.nii']);
c2hdr = spm_vol([redir_mr,'/c2MR.nii']);
c3hdr = spm_vol([redir_mr,'/c3MR.nii']);
BV=spm_read_vols(c1hdr)+spm_read_vols(c2hdr)+spm_read_vols(c3hdr);
rcthdr=spm_vol([redir_ct,'/rCT.nii']);
rctvol=spm_read_vols(rcthdr);
rctvol(BV<.9)=0;
elevol = rctvol.*(rctvol>1100);
[eleCor,elevol_filted] = ele_filt(rctvol,1100,20,100);

%% get cortex surface and electrodes surface
cortex = get_surface(mrhdr,spm_read_vols(c1hdr)+spm_read_vols(c2hdr),.65,2);
sphere = get_surface(mrhdr,spm_read_vols(c1hdr)+spm_read_vols(c2hdr),.47,9);
resp=reducepatch(sphere,5000);
ele = get_surface(rcthdr,elevol_filted,1100,0);

%% patch surfaces
f=figure('color',[0 0 0]);
patch(cortex,'facecolor',[.9 .9 .9],'edgecolor','none');material([.3 .5 .1])
light;
lighting gouraud;
lightangle(270,0);view(270,0);
axis equal; axis off; alpha .6;
% camlight headlight
hold on;
patch(ele,'facecolor',[1 0 0],'edgecolor',[1 0 0]);light;lighting gouraud;
%% save result
cd(redir); 
savefig(f,'result'); 
save ele ele;
save eleCor eleCor; 
