point=zeros(size(ele));
for ele_N=1:length(ele)
    tem=zeros(1,length(brain.vertices));
    for ii=1:length(tem)
        tem(ii)=(ele(ele_N,1:3)-brain.vertices(ii,:))*(ele(ele_N,1:3)-brain.vertices(ii,:))';
    end
    point(ele_N,:)=brain.vertices((tem==min(tem)),:);
    ele_N
end
clear tem ii