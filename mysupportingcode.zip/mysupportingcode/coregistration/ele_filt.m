function [ep,fv]=ele_filt(v,min_intensity,min_voxles,max_voxles)
threshold=min_intensity;
temmr = zeros(size(v));
temmr(v>threshold)=1;
cc=bwconncomp(temmr,18);
index=cc.PixelIdxList;
electrodes = zeros(length(index),3);
ele_filted=zeros(size(v));
for ele=1:length(index);
    if length(index{ele})>min_voxles&&length(index{ele})<max_voxles
        pnts=index{ele};
        ele_filted(pnts)=v(pnts);
        subs=zeros(length(pnts),3);
        for pnt=1:length(pnts);
            [subs(pnt,1),subs(pnt,2),subs(pnt,3)]=ind2sub(size(v),pnts(pnt));
        end
        electrodes(ele,:)=sum(subs.*repmat(v(pnts)./sum(v(pnts)),[1 3]),1);
    end
end
fv=ele_filted;

epN=1;
for ele=1:length(electrodes)
    if isequal(electrodes(ele,:),[0 0 0])==0
        ep(epN,:)=electrodes(ele,:);
        epN=epN+1;
    end
end