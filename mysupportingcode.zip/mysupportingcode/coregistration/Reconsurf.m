%% get surface files from freesurfer
[f1,p1]=uigetfile('.pial','Pick <lh.pial> under /surf');
[f2,p2]=uigetfile('.pial','Pick <rh.pial> under /surf');
[f3,p3]=uigetfile('.mgz','Pick <brain.mgz> under /mri');
[f4,p4]=uigetfile('.mat','Pick <ele.mat> under Result folder of Coregisteration');
[lv,lf]=read_surf([p1,f1]);
lf=lf+1;
[rv,rf]=read_surf([p2,f2]);
rf=rf+1;
header=MRIread([p3,f3],1);
fs_cortex.vertices=[lv;rv];
fs_cortex.vertices(:,1)=fs_cortex.vertices(:,1)+header.c_r;
fs_cortex.vertices(:,2)=fs_cortex.vertices(:,2)+header.c_a;
fs_cortex.vertices(:,3)=fs_cortex.vertices(:,3)+header.c_s;
fs_cortex.faces=[lf;rf+size(lv,1)];
save fs_cortex fs_cortex
ele=load([p4,f4]);
patch(fs_cortex,'facecolor',[.99 .99 .99],'edgecolor','none'),view(3),camlight headlight,lighting gouraud;lightangle(270,0); material([.1 .5 .5]);alpha .8
hold on;
patch(ele,'facecolor',[1 0 0],'edgecolor',[1 0 0]);light;lighting gouraud;
axis equal; axis off;
save(gcf,'FreeSurfer_CT')