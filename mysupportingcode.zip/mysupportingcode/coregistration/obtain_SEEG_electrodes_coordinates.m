function  All_Ele_Positions = obtain_SEEG_electrodes_coordinates()
%% reconstruct SEEG electrodes
%
% input  inner terminals coordinates and another one (for straight line fitting) or two (for curve fitting) points
% in targeted electrodes rods, along with the file where coordinates were
% obtained from.
% out put a table containing all electrodes coordinates; and a .nii file
% that can be used to creat threshold model in 3D Slicer.

% Ben, wcastle90@gmail.com, Oct 11th, 2016;

% specify source file
[f1,p1]=uigetfile('.nii','Choose the .nii file where you obtained the coordinates');
hdr = spm_vol([p1,f1]);

% input information of the electrodes pillars
button = questdlg('I would like to feed in data','How to input','by hand','via EXCEL file','by hand');
if isequal (button,'via EXCEL file')
    [f2, p2] = uigetfile({'*.xls;*.xlsx'},'Please choose one MS EXCEL file containing pillars information');
    Vectors = xlsread([p2,f2]);
    fprintf(['Input Pillars are (start RAS, midway RAS, Num of points): \n']);
    disp(Vectors);
    N_p = size(Vectors,1);
    cords = Vectors;
elseif isequal (button,'by hand')
    % specify Number of pillars
    Answer = inputdlg('Number of pillar =','How many electrodes pillars to be located',[1 80]);
    N_p = str2double(Answer{1});
    P_labels = {};
    for p_ID = 1:N_p
        P_label = ['Pillar ',num2str(p_ID)];
        P_labels = [P_labels,P_label];
    end
    % input coordinates
    Answer = inputdlg(P_labels,'Input the coordinates',[1 50],repmat({'[0 0 0],[1 1 1],[16]'},[N_p,1]));
    cords = [];
    for p_ID = 1:N_p
        cords = [cords;str2num(Answer{p_ID})];
    end
else
    error('dont')
end
% detect where the coordinates are of RSA system or ijk system
if sum(sum(cords<0))>0
    RAS = 1;
else
    RAS = 0;
    error('ijk coordinates not yet supported');
end

%% fit with models and get positions of the electrodes
All_Ele_Positions = [];
fcsv_content = [];
for p_ID = 1:N_p
    Cords_P = cords(p_ID,(1:6));
    Num_Ele = cords(p_ID,end);
    Ele_Positions = locate_electrodes(Cords_P,Num_Ele);
    cell_of_P = cell(size(Ele_Positions,1),14);
    for dot_ID = 1:size(Ele_Positions,1)
        cell_of_P{dot_ID,1} = [num2str(p_ID),'-',num2str(dot_ID)]; % id
        cell_of_P{dot_ID,2} = Ele_Positions(dot_ID,1); % x
        cell_of_P{dot_ID,3} = Ele_Positions(dot_ID,2); % y
        cell_of_P{dot_ID,4} = Ele_Positions(dot_ID,3); % z
        % unknown properties: ow,ox,oy,oz,vis,sel,lock
        cell_of_P{dot_ID,5} = 1;
        cell_of_P{dot_ID,6} = 1;
        cell_of_P{dot_ID,7} = 1;
        cell_of_P{dot_ID,8} = 0;
        cell_of_P{dot_ID,9} = 0;
        cell_of_P{dot_ID,10} = 0;
        cell_of_P{dot_ID,11} = 1;
        % others
        cell_of_P{dot_ID,12} = [num2str(p_ID),'-',num2str(dot_ID)];% label
        cell_of_P{dot_ID,13} = [num2str(p_ID),'-',num2str(dot_ID)]; % desc
        cell_of_P{dot_ID,14} = 'vtkMRMLScalarVolumeNode'; % associatedNodeID
    end
    fcsv_content = [fcsv_content;cell_of_P];
    All_Ele_Positions = [All_Ele_Positions;Ele_Positions];
end
% write files
fcsv_content2w = cell2table(fcsv_content);
fname = [p1,f1,'.fcsv'];
writetable(fcsv_content2w,fname,'FileType','text');
plot3(All_Ele_Positions(:,1),All_Ele_Positions(:,2),All_Ele_Positions(:,3),'r.')
%% creat volume
[x y z]=ind2sub(hdr.dim,1:prod(hdr.dim));
voxel_N=prod(hdr.dim);
index=[x;y;z;ones(1,length(x))];
transf=hdr.mat;
cord_sys=single(transf*index);
vol=zeros(voxel_N,1);
h = waitbar(0,'creating electrods volume');
for ele_num=1:length(All_Ele_Positions)
    ele_cor=single(All_Ele_Positions(ele_num,:));
    tem=repmat(ele_cor,[voxel_N 1]);
    dv=cord_sys(1:3,:)'-tem;
    d=mean((dv.*dv),2);
    vol=vol+exp(-d)*1000;
    waitbar(ele_num/length(All_Ele_Positions),h);
end
if exist('h')
    delete(h);
end
vol=reshape(vol,hdr.dim);
hdr.fname=['SEEG_electrodes.nii'];
cd(p1);
spm_write_vol(hdr,vol);

function Ele_Positions = locate_electrodes(coordinates,Ele_Num)
if numel(coordinates)==6 % fit with a straight line
    direction = [coordinates(4:6)-coordinates(1:3)];
    direction = direction/(normest(direction)/3.5);
    start = [coordinates(1:3)];
    Ele_Positions = zeros(Ele_Num,3);
    for Ele_ID = 1:Ele_Num
        Ele_Positions(Ele_ID,:) = start + (Ele_ID-1)*direction;
    end
    
elseif numel(coordinates)==9 % fit with a curve
    error('not yet finished');
else error('there is a bug')
end
