%%  A coregistration program which can project CT, MRV, MRA, etc to MRP images
% and clear artifects out of the skull;
%%  Need spm12 toolbox and dicm2nii toolbox;

% Jianbin Wen
% Wcastle90@gmail.com
% Sep 15th, 2015
%% Revised at Nov 27th, 2015

%% get input;
% reference image
mridir=uigetdir(pwd,'Please spercific a folder which contain T1 dicoms as REFERENCE image');

%source images
IM_Num = inputdlg('Number of images =','How many types of images to coregister',[1 80]);
IM_Num=str2double(IM_Num{1});
sourcedir=cell(IM_Num,1);
for ii=1:IM_Num
    sourcedir{ii}=uigetdir(pwd,['Please spercify a folder containing dicoms for coregistration, ',num2str(ii-1),' of ',num2str(IM_Num),' folders has been choosen']);
end

%folder to save result files.
redir = uigetdir(pwd,'Choose folder to save results');
Sub_info = inputdlg('name (or ID, etc) =','Please enter the subject name or ID, etc',[1 80]);
subredir=[redir,'/',Sub_info{1}];
if exist(subredir,'dir')==0
    mkdir(redir,Sub_info{1});
end

%% dicm2nii
% convert MRI
redir_mr = [subredir,'/MR_nii'];
if exist(redir_mr,'dir')==0
    mkdir(subredir,'MR_nii');
end
dicm2nii(mridir,redir_mr,0);
Files = dir(fullfile(redir_mr,'*.nii'));
fname=[redir_mr,'/',Files(1).name];
hdr=spm_vol(fname);
vol=spm_read_vols(hdr);
hdr.fname=[redir_mr,'/MR.nii'];
cd (redir_mr);
spm_write_vol(hdr,vol);
mrhdr=hdr;

% convert source images
redir_source=cell(IM_Num,1);
hdrs=cell(IM_Num,1);
for ii=1:IM_Num
    redir_source{ii}=[subredir,'/image',num2str(ii)];
    if  exist(redir_source{ii},'dir')==0
        mkdir(redir_source{ii});
    end
    dicm2nii(sourcedir{ii},redir_source{ii},0);
    Files = dir(fullfile(redir_source{ii},'*.nii'));
    fname=[redir_source{ii},'/',Files(1).name];
    hdr=spm_vol(fname);
    for dim=1:3
        factors=hdr.mat(dim,1:3);
        hdr.mat(dim,4)=-hdr.mat(dim,1:3)*hdr.dim'/2;
    end
    vol=spm_read_vols(hdr);
    hdr.fname=[redir_source{ii},'/image',num2str(ii),'.nii'];
    cd (redir_source{ii});
    spm_write_vol(hdr,vol);
    hdrs{ii}=hdr;
end

%% MRI segmentation
% spm segmentation
h=msgbox('This step may take up to 10 minutes, DO JUST WAIT.','Segmentation','warn');
kouSPMdir = spm('Dir');
spm_jobman('initcfg')
nrun = 1; % enter the number of runs here
inputs = cell(0, nrun);
SPMdir = spm('Dir');
for crun = 1:nrun
end
spm('defaults', 'fMRI');
eval('spmscript_seg');
spm_jobman('run', matlabbatch, inputs{:});
clear matlabbatch;
if exist('h')
    delete(h);
end

%% SPM coregistration and reslice
for ii=1:IM_Num
    nrun = 1; % enter the number of runs here
    matlabbatch{1}.spm.spatial.coreg.estwrite.ref = {[mrhdr.fname,',1']};
    matlabbatch{1}.spm.spatial.coreg.estwrite.source = {[hdrs{ii}.fname,',1']};
    matlabbatch{1}.spm.spatial.coreg.estwrite.other = {''};
    matlabbatch{1}.spm.spatial.coreg.estwrite.eoptions.cost_fun = 'nmi';
    matlabbatch{1}.spm.spatial.coreg.estwrite.eoptions.sep = [4 2];
    matlabbatch{1}.spm.spatial.coreg.estwrite.eoptions.tol = [0.02 0.02 0.02 0.001 0.001 0.001 0.01 0.01 0.01 0.001 0.001 0.001];
    matlabbatch{1}.spm.spatial.coreg.estwrite.eoptions.fwhm = [7 7];
    matlabbatch{1}.spm.spatial.coreg.estwrite.roptions.interp = 4;
    matlabbatch{1}.spm.spatial.coreg.estwrite.roptions.wrap = [0 0 0];
    matlabbatch{1}.spm.spatial.coreg.estwrite.roptions.mask = 0;
    matlabbatch{1}.spm.spatial.coreg.estwrite.roptions.prefix = 'r';
    inputs = cell(0, nrun);
    for crun = 1:nrun
    end
    spm('defaults', 'FMRI');
    spm_jobman('run', matlabbatch, inputs{:});
end

%% remove skull in CT images using coordinates from MR segments
c1hdr = spm_vol([redir_mr,'/c1MR.nii']);
c2hdr = spm_vol([redir_mr,'/c2MR.nii']);
c3hdr = spm_vol([redir_mr,'/c3MR.nii']);
c5hdr = spm_vol([redir_mr,'/c5MR.nii']);
BV=spm_read_vols(c1hdr)+spm_read_vols(c2hdr)+spm_read_vols(c3hdr)+spm_read_vols(c5hdr)*.5;
BV=sm_filt(BV,6);
for ii=1:IM_Num
sourcehdr=spm_vol([redir_source{ii},'/rimage',num2str(ii),'.nii']);
sourcevol=spm_read_vols(sourcehdr);
sourcevol(BV<.55)=0;
% elevol = rctvol.*(rctvol>1200);
% [eleCor,elevol_filted] = ele_filt(elevol);
sourcehdr.fname = [redir_source{ii},'/out_rimage',num2str(ii),'.nii'];
spm_write_vol(sourcehdr,sourcevol);
end

clear;