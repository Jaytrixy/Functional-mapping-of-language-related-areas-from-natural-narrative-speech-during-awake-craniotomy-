%% reconstruct cortex and sphere out of segmentatioins from SPM

mridir=uigetdir(pwd,'Please spercific a folder which contains segmentations');
mrhdr = spm_vol([mridir,'/MR.nii']);
c1hdr = spm_vol([mridir,'/c1MR.nii']);
c2hdr = spm_vol([mridir,'/c2MR.nii']);
cortex = get_surface(mrhdr,spm_read_vols(c1hdr)+spm_read_vols(c2hdr),.65,2);

%% save files
CreateModelforBFMnBrainNet(cortex,mridir);
save([mridir,'/cortex_struct'],'cortex');
%% patch surfaces
f=figure('color',[0 0 0]);
patch('Vertices', cortex.vert, 'Faces', cortex.tri ,'facecolor',[.9 .9 .9],'edgecolor','none');material([.3 .5 .1])
light;
lighting gouraud;
lightangle(270,0);view(270,0);
axis equal; axis off; alpha .6;
savefig(f,[mridir,'/cortex_model']);