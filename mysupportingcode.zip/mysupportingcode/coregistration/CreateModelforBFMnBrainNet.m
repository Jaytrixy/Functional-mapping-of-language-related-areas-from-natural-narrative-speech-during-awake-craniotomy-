function CreateModelforBFMnBrainNet(cortex,outdir)
%% Creat model for BFM
fid = fopen([outdir,'tri.txt'],'wb');
for i=1:size(cortex.tri,1)
    fprintf(fid,'%d\t%d\t%d',cortex.tri(i,1),cortex.tri(i,2),cortex.tri(i,3));
    fprintf(fid,'\r\n');
end
fclose(fid);

fid = fopen([outdir,'vert.txt'],'wb');
for i=1:size(cortex.vert,1)
    fprintf(fid,'%f\t%f\t%f',cortex.vert(i,1),cortex.vert(i,2),cortex.vert(i,3));
    fprintf(fid,'\r\n');
end
fclose(fid);

%% Creat model for BrainNet
% dlmwrite('Longquan.nv',length(vert),'delimiter','\t','precision',6);
% dlmwrite('Longquan.nv',vert,'delimiter','\t','precision',6,'-append');
% dlmwrite('Longquan.nv',length(face),'delimiter','\t','precision',6,'-append');
% dlmwrite('Longquan.nv',face,'delimiter','\t','precision',6,'-append');