%% get surface files from freesurfer
sourcedir=uigetdir(pwd,'Please spercific a source folder named as <Subjectname> under Freesurfer/subjects/');
f1 = ([sourcedir,'/surf/lh.pial']);
f2 = ([sourcedir,'/surf/rh.pial']);
f3 = ([sourcedir,'/mri/brain.mgz']);

%% specify target directory
resultdir=uigetdir(pwd,'Please spercific a target folder to save result.');

%% Read vertices and faces of left and right hemisphere, +1 since Fresurfer creat faces from index 0;
[lv,lf]=read_surf(f1);
lf=lf+1;
[rv,rf]=read_surf(f2);
rf=rf+1;

%% Read transposition vector from header of volume file.
header=MRIread(f3,1);

%% Apply correction to vertices coordinate;
lv(:,1) = lv(:,1) + header.c_r;
lv(:,2) = lv(:,2) + header.c_a;
lv(:,3) = lv(:,3) + header.c_s;
rv(:,1) = rv(:,1) + header.c_r;
rv(:,2) = rv(:,2) + header.c_a;
rv(:,3) = rv(:,3) + header.c_s;

%% Save result
write_surf([resultdir,'/corrected_lh.pial'],lv,lf);
write_surf([resultdir,'/corrected_rh.pial'],rv,rf);

%% clear memory
clear all