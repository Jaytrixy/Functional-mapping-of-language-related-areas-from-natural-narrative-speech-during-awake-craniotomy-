%% Project surface electrodes strips onto a brain envelope;
% Jianbin Wen
% Wcastle90@gmail.com
% Dec 23th, 2015

%%
% modified at Dec 30th, 2015, each electrode are now compact cluster, not
% like dispersed dots.
%% Revised at Jan 19th, 2016
% 
%% Choose your own parameters if necessary;
min_intensity = 1200; %% Choose your own electrodes threshold if neccessary;
contour_sh =.45;  %% Choose your own contour threshold of brain envelope if neccessary, smaller threshold yeild a bigger envelope;

%% get files
[MR_files, MRpath] = uigetfile('*.nii','Please choose C1MR.nii and C2MR.nii files under SUBJECT/MR_nii/','MultiSelect','on');
if (iscell(MR_files)&&length(MR_files)~=2) || ~iscell(MR_files)
    error('Please choose TWO files!');
end
[CT_files,CTpath] = uigetfile('*.nii','Please choose out_rimage*.nii refering to CT image under SUBJECT/image*/');
if iscell(CT_files)&&length(CT_files)~=1
    error('Please choose ONE file!');
end
disp('read files');
tic;
%% read files
hdrC1=spm_vol([MRpath,MR_files{1}]);
% volC1=spm_read_vols(hdrC1);
hdrC2=spm_vol([MRpath,MR_files{2}]);
% volC2=spm_read_vols(hdrC2);
% hdrC3=hdrC1;
% hdrC3.fname = [hdrC1.fname(1:end-8),'c3MR.nii'];
% volC3=spm_read_vols(hdrC3);
hdrCT=spm_vol([CTpath,CT_files]);
volCT=spm_read_vols(hdrCT);
toc;
%% create sphere to project the electrodes
disp('building brain envelop');
sphere = get_surface(hdrC1,spm_read_vols(hdrC1)+spm_read_vols(hdrC2),contour_sh,9);
toc;
%% filt electrodes out using Intensity and Cluster
disp('searching electrodes in CT image');
voxelsize = sum(hdrC1.mat,1);
voxelvolum = abs(prod(voxelsize(1:3)));
[ep,fv] = ele_filt(volCT,min_intensity,ceil(3/voxelvolum),ceil(20/voxelvolum));
toc;
%% approximation
disp('projecting electrodes to brain envelop');
subspt = zeros(1,3);
sphere.vertices = sphere.vertices';
sphere.vertices(4,:) = 1;
sphere.vertices = (hdrC1.mat)^-1*sphere.vertices;
sphere.vertices(4,:)=[];
sphere.vertices=sphere.vertices';
pp = zeros(size(ep));
for PN=1:size(ep,1)
    pointset = repmat (ep(PN,:),[length(sphere.vertices),1]);
    tem = dot (pointset-sphere.vertices,pointset-sphere.vertices,2);
    pp(PN,:)=fix(sphere.vertices((tem==min(tem)),:));
end
[x y z]=ind2sub(hdrC1.dim,1:prod(hdrC1.dim));
voxel_N=prod(hdrC1.dim);
index=[x;y;z;ones(1,length(x))];
transf=hdrC1.mat;
cord=single(transf*index);
vol=zeros(voxel_N,1);
pp = [pp,ones(size(pp,1),1)]';
pp = single(transf*pp);
 for ele_num=1:length(pp)
        ele_cor=single(pp(1:3,ele_num)');
        tem=repmat(ele_cor,[voxel_N 1]);
        dv=cord(1:3,:)'-tem;
        d=mean((dv.*dv),2);
        vol=vol+exp(-d)*2400;
 end
vol=reshape(vol,hdrC1.dim);clear cord tem d;
toc;
%% approximation 2
temmr = zeros(size(fv));
temmr(fv>min_intensity)=1;
cc=bwconncomp(temmr,18); clear temmr;
index=cc.PixelIdxList;
ele_projected=zeros(size(fv));
for ele=1:length(index);
    pnts=index{ele};
    subs=zeros(length(pnts),3);
    for pnt=1:length(pnts);
        [subs(pnt,1),subs(pnt,2),subs(pnt,3)]=ind2sub(size(fv),pnts(pnt));
    end
    cors = subs;
    transpositions = zeros(size(subs));
    for pnt_num=1:length(cors)
        pnt_cor=single(cors(pnt_num,:));
        pointset=repmat(pnt_cor,[length(sphere.vertices) 1]);
        tem = dot(pointset-sphere.vertices,pointset-sphere.vertices,2);
        [s1]=(sphere.vertices((tem==min(tem)),:));
        transpositions(pnt_num,:) = s1(1,:)-subs(pnt_num,:);
    end
    TP = fix(mean(transpositions,1));
    for pnt=1:length(pnts);
        ele_projected(subs(pnt,1)+TP(1),subs(pnt,2)+TP(2),subs(pnt,3)+TP(3))=fv(pnts(pnt));
    end
end
%% write and save result
disp('saving results');
outhdr = hdrCT;
outhdr.fname = [CTpath,'Filted.nii'];
spm_write_vol(outhdr,fv);
outhdr.fname = [CTpath,'Projected1.nii'];
spm_write_vol(outhdr,vol);
outhdr.fname = [CTpath,'Projected2.nii'];
spm_write_vol(outhdr,ele_projected);
toc;
disp('done');
clear;