% To creat a .epf file that contains coordinates of known electrodes
 fid = fopen([filename,'.epf'],'w');
 fprintf(fid,'<?xml version="1.0" encoding="utf-8"?>');
 fprintf(fid,'\n<Position>\n');
for i=1:size(electrodes,1)
    fprintf(fid,'\t<Electrode red=".5" green="3" blue="0.5" radius="2">\n');
    fprintf(fid,'\t\t<X>%f</X>\n',electrodes(i,1));
    fprintf(fid,'\t\t<Y>%f</Y>\n',electrodes(i,2));
    fprintf(fid,'\t\t<Z>%f</Z>\n',electrodes(i,3));
    fprintf(fid,'\t</Electrode>\n');
end
fprintf(fid,'</Position>');
fclose(fid);