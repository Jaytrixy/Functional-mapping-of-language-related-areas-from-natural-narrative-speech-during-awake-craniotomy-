%% read BrainProduct .eeg
function [event, data] = readbpeeg()
[fname, path]= uigetfile('C:\Vision\Raw Files/*.vhdr','choose file');
cfg.dataset = [path,fname];

dataset = ft_preprocessing(cfg);
event = ft_read_event([path,fname]);
data = dataset.trial{1};