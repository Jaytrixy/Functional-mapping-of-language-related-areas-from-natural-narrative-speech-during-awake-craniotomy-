
function k=makeGkernal(m,n)
%% make 2-D Gaussian kernal for smooth
mu = [(1+m)/2 (n+1)/2];
Sigma = mu./2;
x1 = 1:m; x2 = 1:n;
[X1,X2] = meshgrid(x1,x2);
k = mvnpdf([X1(:) X2(:)],mu,Sigma);
k=reshape(k,n,m);
k=k/sum(sum(k));
