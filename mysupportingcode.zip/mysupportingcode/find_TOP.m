%% get t value coresponding to certain p
function out_T = find_TOP(p,df)
t = -20:.01:20;
cdf_P = tcdf(t,df);
out_T  = t(find(cdf_P>1-p,1,'first'));