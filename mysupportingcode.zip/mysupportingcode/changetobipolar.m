function [outdata, channelnames] = changetobipolar(data,electroNumbers,do)
%% change the data to bipolar recording and return channel names
% input, original data and number of electrodes on each pillar
% output, bipolar data and new channel names;

if do
    outdata = [];
    channels = 0;
    channelnames = {};
   for pillarID = 1:length(electroNumbers)
       if electroNumbers(pillarID)==1
           error('can not derive bipolar recording from just 1 channel')
       end
       channels = channels(end) + [1:electroNumbers(pillarID)];
       outdata = [outdata;diff(data(channels,:),1,1)];
       for electroID = 1:electroNumbers(pillarID)-1;
           channelnames = [channelnames,['P',num2str(pillarID),' ',num2str(electroID+1),'-',num2str(electroID)]];
       end
   end
else
    outdata = data;
    channelnames = {};
    for channelID = 1:size(data,1)
        channelnames = [channelnames,['Ch',num2str(channelID)]];
    end
end