%% Recording data from Brain vision Recorder and Save to files

function RecordData =  My_RDA_recording()

% global definitions of controls for easy use in other functions
finish = false;
subname = inputdlg ('Subname:');
% Create and hide the GUI figure as it is being constructed.
f = figure('Visible','off',...
    'Position',[0,0,350,50]);
% *** Construct the controls ***
% controls for connection with host
lblHost = uicontrol('Style','text','String','Host:',...
    'BackgroundColor',get(f,'Color'),'Position',[25,20,50,16]);
editHost = uicontrol('Style','edit','String','localhost',...
    'Position',[75,20,150,16]);
btConnect = uicontrol('Style','pushbutton','String','Connect',...
    'Position',[230,20,100,16],...
    'Callback',{@btConnect_Callback});

% Assign the GUI a name to appear in the window title.
set(f,'Name','Brain Vision RDA Client for MATLAB')
% Move the GUI to the center of the screen.
movegui(f,'center')
% Make the GUI visible.
set(f,'Visible','on');


%% ***********************************************************************
% Connection handling functions

% --- Pushbutton handler: executes on button press in btConnect.
function btConnect_Callback(hObject, eventdata)
% hObject    handle to btConnect
% eventdata  reserved - to be defined in a future version of MATLAB
text = get(hObject, 'String');
if strcmp(text, 'Connect')
    delete(hObject);
    OpenConnection();     
end
end
%% ********************************************************************
% Connection opening
function OpenConnection()
recorderip = get(editHost, 'String');

% Establish connection to BrainVision Recorder Software 32Bit RDA-Port
% (use 51234 to connect with 16Bit Port)
con=pnet('tcpconnect', recorderip, 51244);

% Check established connection and display a message
stat=pnet(con,'status');
if stat > 0
    disp('connection established');
else
    error('?')
end
% --- Main reading loop ---
    close(f);
    main_loop();
end
%% **********************************************************************
%main loop
function main_loop()
RecordData = struct('data',[],'Markers',[],'Audio',[]);
while ~finish
    try
        % check for existing data in socket buffer
        tryheader = pnet(con, 'read', header_size, 'byte', 'network', 'view', 'noblock');
        while ~isempty(tryheader)
            
            % Read header of RDA message
            hdr = ReadHeader(con);
           
            % Perform some action depending of the type of the data package
            switch hdr.type
                case 1       % Start, Setup information like EEG properties
                    disp('Start');
                    % Read and display EEG properties
                    props = ReadStartMessage(con, hdr);
                    disp(props);
                    
                    % Reset block counter to check overflows
                    lastBlock = -1;
                    
                    % set data buffer to empty
                    data1s = rand(props.channelCount,1000000 / props.samplingInterval);
                    
                case 4       % 32Bit Data block
                    % Read data and markers from message
                    %                     [datahdr, data, markers] = ReadDataMessage(con, hdr, props);
                    data_info = swapbytes(pnet(con,'read', 3, 'uint32', 'network'));
                    
                    % Read data in float format
                    data = swapbytes(pnet(con,'read', props.channelCount * data_info(2), 'single', 'network'));
                 
                    % check tcpip buffer overflow
                    if lastBlock == -1 && data_info(1) ~= lastBlock
                        startBlock = data_info(1);
                    end
                    if lastBlock ~= -1 &&  data_info(1) > lastBlock + 1
                        disp(['******* Overflow with ' int2str(data_info(1)  - lastBlock) ' blocks ******',int2str(data_info(1)),' - ' ,int2str(lastBlock)]);
                    end
                    lastBlock = data_info(1) ;
                    waitbar(double(data_info(1)-startBlock)/30000);
                    fwrite(fid,data,'single');
                    if double(data_info(1)-startBlock)>=30000
                          CloseConnection();
                          delete(Cdown);
                          disp('Recording finish');
                          fclose(fid);
                          break;
                    end
                    
                    
                case 3       % Stop message
                    disp('Stop');
                    data = pnet(con, 'read', hdr.size - header_size);
                    finish = true;
                    
                otherwise    % ignore all unknown types, but read the package from buffer
                    data = pnet(con, 'read', hdr.size - header_size);
            end
            tryheader = pnet(con, 'read', header_size, 'byte', 'network', 'view', 'noblock');
        end
    catch
        error('SORRY FOR THIS...')
    end
end % Main loop



end
%% ***********************************************************************
% Connection closing
function CloseConnection()

% global definitions
finish = true;
fclose(fid);
% Close all open socket connections
pnet('closeall');
% Display a message
disp('connection closed');

end
%% ***********************************************************************
% Read the message header
function hdr = ReadHeader(con)
% con    tcpip connection object

% define a struct for the header
hdr = struct('uid',[],'size',[],'type',[]);

% read id, size and type of the message
% swapbytes is important for correct byte order of MATLAB variables
% pnet behaves somehow strange with byte order option
hdr.uid = pnet(con,'read', 16);
hdr.size = swapbytes(pnet(con,'read', 1, 'uint32', 'network'));
hdr.type = swapbytes(pnet(con,'read', 1, 'uint32', 'network'));

end
%% ***********************************************************************
% Read the start message
function props = ReadStartMessage(con, hdr)
% con    tcpip connection object
% hdr    message header
% props  returned eeg properties

% define a struct for the EEG properties
props = struct('channelCount',[],'samplingInterval',[],'resolutions',[],'channelNames',[]);

% read EEG properties
props.channelCount = swapbytes(pnet(con,'read', 1, 'uint32', 'network'));
props.samplingInterval = swapbytes(pnet(con,'read', 1, 'double', 'network'));
props.resolutions = swapbytes(pnet(con,'read', props.channelCount, 'double', 'network'));
allChannelNames = pnet(con,'read', hdr.size - 36 - props.channelCount * 8);
props.channelNames = SplitChannelNames(allChannelNames);

end
%% ***********************************************************************
% Read a data message
function [datahdr, data, markers] = ReadDataMessage(con, hdr,props)
% con       tcpip connection object
% hdr       message header
% props     eeg properties
% datahdr   data header with information on datalength and number of markers
% data      data as one dimensional arry
% markers   markers as array of marker structs

% Define data header struct and read data header
datahdr = struct('block',[],'points',[],'markerCount',[]);

datahdr.block = swapbytes(pnet(con,'read', 1, 'uint32', 'network'));
datahdr.points = swapbytes(pnet(con,'read', 1, 'uint32', 'network'));
datahdr.markerCount = swapbytes(pnet(con,'read', 1, 'uint32', 'network'));

% Read data in float format
data = swapbytes(pnet(con,'read', props.channelCount * datahdr.points, 'single', 'network'));

    
    % Define markers struct and read markers
    markers = struct('size',[],'position',[],'points',[],'channel',[],'type',[],'description',[]);
    for m = 1:datahdr.markerCount
        marker = struct('size',[],'position',[],'points',[],'channel',[],'type',[],'description',[]);
        
        % Read integer information of markers
        marker.size = swapbytes(pnet(con,'read', 1, 'uint32', 'network'));
        marker.position = swapbytes(pnet(con,'read', 1, 'uint32', 'network'));
        marker.points = swapbytes(pnet(con,'read', 1, 'uint32', 'network'));
        marker.channel = swapbytes(pnet(con,'read', 1, 'int32', 'network'));
        
        % type and description of markers are zero-terminated char arrays
        % of unknown length
        c = pnet(con,'read', 1);
        while c ~= 0
            marker.type = [marker.type c];
            c = pnet(con,'read', 1);
        end
        
        c = pnet(con,'read', 1);
        while c ~= 0
            marker.description = [marker.description c];
            c = pnet(con,'read', 1);
        end
        
        % Add marker to array
        markers(m) = marker;
    end

end
%% ***********************************************************************
% Helper function for channel name splitting, used by function
% ReadStartMessage for extraction of channel names
function channelNames = SplitChannelNames(allChannelNames)
% allChannelNames   all channel names together in an array of char
% channelNames      channel names splitted in a cell array of strings

% cell array to return
channelNames = {};

% helper for actual name in loop
name = [];

% loop over all chars in array
for i = 1:length(allChannelNames)
    if allChannelNames(i) ~= 0
        % if not a terminating zero, add char to actual name
        name = [name allChannelNames(i)];
    else
        % add name to cell array and clear helper for reading next name
        channelNames = [channelNames {name}];
        name = [];
    end
end
end

end