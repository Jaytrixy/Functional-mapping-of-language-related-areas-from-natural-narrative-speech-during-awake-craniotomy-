function acc_P=secondtest(pmatrix,t_s,f_s)
[D1,D2]=size(pmatrix);
acc_P=zeros(D1,D2);
for ii=1:D1-f_s
    for jj=1:D2-t_s
        if max(max(pmatrix(ii:ii+f_s,jj:jj+t_s)))<.05
            acc_P(ii:ii+f_s,jj:jj+t_s)=1;
        end
    end
end
