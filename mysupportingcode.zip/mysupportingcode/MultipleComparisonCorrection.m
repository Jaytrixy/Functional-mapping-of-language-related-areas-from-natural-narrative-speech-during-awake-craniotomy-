%% FDR and cluster-based multiple comparison correction

%% orig
X = eeglab_hg;
Y = env';
lag = 5;
[R]= Get_index_release(X,Y,lag);
%% statistics
R2 = R.^2;
DF = length(X)-2;
[T] = ((R2*DF)./(1-R2)).^(0.5);
p = tcdf(T,DF,'upper');

%% FDR
for chID = 1:size(R,1)
 [hp(chID,:), crit_p(chID,:), adj_ci_cvrg(chID,:), adj_p(chID,:)] = fdr_bh(p(chID,:),.001);
end

%%  Bonferroni
b_bof = p/size(p,2);

%% cluster-based
Max_cluster_index = [];
Max_cluster_center = [];
for chID =1:size(R,1)
    CC = bwconncomp(p(chID,:)<0.001);  
    if CC.NumObjects>0
        for clusterID = 1:CC.NumObjects
            CC.cluster_index(clusterID) = sum(T(chID,CC.PixelIdxList{clusterID}));
            CC.cluster_center(clusterID) = sum(T(chID,CC.PixelIdxList{clusterID})'.*CC.PixelIdxList{clusterID})/CC.cluster_index(clusterID);
        end
       [Max_cluster_index(chID),clusterID] = max(CC.cluster_index);
       [Max_cluster_center(chID)] = CC.cluster_center(clusterID);
    end     
end   
%% let's do permutation  
if size(X,2)>size(X,1)
    X = X';
end
if size(Y,2)>size(Y,1)
    Y = Y';
end
if length(X)>=length(Y) % realign the data
    X(length(Y)+1:end) = [];
else
    Y(length(X)+1:end,:)  =[];
end
per_Num = 2000;
% shuffle Y
Y = Y((lag*100+1):(end-lag*100));
per_lag = randi(length(env),1,per_Num);
per_cluster_index = zeros(1000,64);
per_Y = zeros(length(Y),per_Num);
for per_ID = 1:per_Num
    per_Y(:,per_ID) = circshift(Y,per_lag(per_ID)); 
end

% adjust x 
delay_period = -lag*100:1:lag*100; % -2000ms to +2000ms of delay
per_R = zeros(per_Num,64,length(delay_period));
for delay = 1:length(delay_period)
    delay
    per_R(:,:,delay) = corr(per_Y,X((lag*200+2-delay*1):(end+1-delay*1),:));
end

%%
[per_R2] = per_R.^2;
[per_T] = ((per_R2*DF)./(1-per_R2)).^(0.5);
[per_p] = tcdf(per_T,DF,'upper');
for chID =1:size(R,1)
        CC = bwconncomp(per_p(chID,:)<0.001);
        if CC.NumObjects>0
            for clusterID = 1:CC.NumObjects
                CC.cluster_index(clusterID) = sum(per_T(chID,CC.PixelIdxList{clusterID}));
            end
            [per_cluster_index(per_ID,chID)] = max(CC.cluster_index);
        end
end
    
    
