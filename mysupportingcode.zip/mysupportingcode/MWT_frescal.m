
function scale=MWT_frescal(fre,w0)

% this is to calculate the scale given frequency 
% the formaula is different for different wavelet function
% this function, just for morlet transform


factor =(4*pi)/(w0 + sqrt(2 + w0^2)); % Scale - Fourier  Equation (3)
scale=1./(factor.*fre);

return,




