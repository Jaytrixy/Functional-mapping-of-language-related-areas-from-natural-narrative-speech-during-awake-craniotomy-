function Wx=M_wt(x,dt,fre,w0)


% x: x-series 
% dt: sampling period:  1/f
% fre: frequency series: such as fre=1:200;

if (nargin <4), w0=6; end
scale=MWT_frescal(fre,w0);
% [Wx,~]= MWT(x,1/2500,scale); 
[Wx,~]= MWT(x,dt,scale); 
